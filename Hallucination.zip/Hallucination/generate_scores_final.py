import os, json, joblib, numpy as np, warnings
from tqdm import tqdm
os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
warnings.filterwarnings(action='ignore', category=UserWarning)

from agent_pattern import extract_advanced_features
import agent_semantic, agent_nli

# --- Define Paths ---
MODEL_DIR = 'tuned_model'
TEACHER_MODEL_PATH = os.path.join(MODEL_DIR, 'tuned_lgbm_model.joblib')

PSEUDO_DATA_DIR = 'pseudo_data'
SCORED_DATA_OUTPUT_FILE = os.path.join(PSEUDO_DATA_DIR, 'unlabeled_with_final_scores.json')

def generate_hybrid_features(data_point, semantic_model, nli_model):
    semantic_score = agent_semantic.get_semantic_similarity_score(data_point, semantic_model)
    nli_score = agent_nli.get_nli_contradiction_score(data_point, nli_model)
    linguistic_features = extract_advanced_features(data_point)
    return [semantic_score, nli_score] + linguistic_features

def main():
    if not os.path.exists(PSEUDO_DATA_DIR): os.makedirs(PSEUDO_DATA_DIR)
    print("--- Loading Teacher Model and Feature Generators ---")
    if not os.path.exists(TEACHER_MODEL_PATH):
        print(f"Error: Teacher model not found at '{TEACHER_MODEL_PATH}'. Please run main_tuned.py first.")
        return
        
    semantic_model = agent_semantic.load_model()
    nli_model = agent_nli.load_model()
    teacher_model = joblib.load(TEACHER_MODEL_PATH)

    print("\n--- Loading Unlabeled Training Data ---")
    unlabeled_filepath = 'D:\\Hallucination\\Data\\SHROOM_unlabeled-training-data-v2\\SHROOM_unlabeled-training-data-v2\\train.model-agnostic.json'
    with open(unlabeled_filepath, 'r', encoding='utf-8') as f:
        unlabeled_data = json.load(f)

    print("\n--- Generating Final Scores for All Unlabeled Data (This will take a while) ---")
    scored_dataset = []
    for dp in tqdm(unlabeled_data, desc="Generating Final Scores"):
        feature_vector = generate_hybrid_features(dp, semantic_model, nli_model)
        
        # Get the probability from the teacher model
        predicted_prob = teacher_model.predict_proba(np.array(feature_vector).reshape(1, -1))[0][1]
        
        new_dp = dp.copy()
        # We only need to store the original data point and its predicted probability
        new_dp['predicted_prob'] = float(predicted_prob)
        scored_dataset.append(new_dp)
    
    print(f"\nSaving the final scored dataset to '{SCORED_DATA_OUTPUT_FILE}'...")
    with open(SCORED_DATA_OUTPUT_FILE, 'w', encoding='utf-8') as f:
        json.dump(scored_dataset, f) # No indent for a smaller file
    print("Save complete.")

if __name__ == '__main__':
    main()