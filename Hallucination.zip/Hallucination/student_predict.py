import os
import json
import numpy as np
from tqdm import tqdm
import joblib
from sklearn.metrics import classification_report, f1_score

os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning)

# Import the feature generators
from agent_pattern import extract_advanced_features
import agent_semantic
import agent_nli

# --- Configuration ---
# This MUST match the model you want to test
CONFIDENCE_THRESHOLD = 0.95 
# ---------------------

# --- THE MAIN CHANGE IS HERE ---
# We now point to the 'student_model' directory and the correct model file
MODEL_DIR = f'student_model_conf_{int(CONFIDENCE_THRESHOLD*100)}'
STUDENT_MODEL_PATH = os.path.join(MODEL_DIR, 'student_lgbm_model.joblib')
# --------------------------------

TEST_DATA_PATH = 'D:\\Hallucination\\Data\\SHROOM_test-labeled\\SHROOM_test-labeled\\test.model-agnostic.json'


# --- IMPORTANT: This feature generation logic MUST be identical to the one in your final training script ---
def get_heuristic_prediction(data_point, semantic_score, nli_score):
    linguistic_features = extract_advanced_features(data_point)
    is_circular_def, number_mismatch = linguistic_features[4], linguistic_features[5]
    if nli_score > 0.95: return "Hallucination"
    if semantic_score < 0.5: return "Hallucination"
    if is_circular_def == 1 or number_mismatch == 1: return "Hallucination"
    if semantic_score > 0.90 and nli_score < 0.1: return "Not Hallucination"
    if semantic_score > 0.75 and nli_score < 0.5: return "Not Hallucination"
    return "Not Hallucination"

def generate_hybrid_features(data_point, semantic_model, nli_model):
    semantic_score = agent_semantic.get_semantic_similarity_score(data_point, semantic_model)
    nli_score = agent_nli.get_nli_contradiction_score(data_point, nli_model)
    linguistic_features = extract_advanced_features(data_point)
    heuristic_pred_str = get_heuristic_prediction(data_point, semantic_score, nli_score)
    heuristic_feature = 1 if heuristic_pred_str == 'Hallucination' else 0
    return [semantic_score, nli_score] + linguistic_features + [heuristic_feature]
# ----------------------------------------------------------------------------------

def main():
    print(f"--- Loading STUDENT Model (trained with {CONFIDENCE_THRESHOLD*100}% confidence pseudo-labels) ---")
    if not os.path.exists(STUDENT_MODEL_PATH):
        print(f"Error: Student model not found at '{STUDENT_MODEL_PATH}'. Please run main_student.py first.")
        return
            
    semantic_model = agent_semantic.load_model()
    nli_model = agent_nli.load_model()
    student_model = joblib.load(STUDENT_MODEL_PATH)
    
    with open(TEST_DATA_PATH, 'r', encoding='utf-8') as f:
        test_data = json.load(f)
    
    print("\n--- Generating Predictions with Final STUDENT Model ---")
    predicted_labels = []
    for dp in tqdm(test_data, desc="Predicting with Student Model"):
        feature_vector = generate_hybrid_features(dp, semantic_model, nli_model)
        prediction = student_model.predict(np.array(feature_vector).reshape(1, -1))[0]
        final_label = "Hallucination" if prediction == 1 else "Not Hallucination"
        predicted_labels.append(final_label)
    
    print("\n--- STUDENT MODEL Performance on Official Test Data ---")
    true_labels = [dp['label'] for dp in test_data]
    print(classification_report(true_labels, predicted_labels))
    macro_f1 = f1_score(true_labels, predicted_labels, average='macro', zero_division=0)
    
    print("=====================================================")
    print(f"  FINAL STUDENT MODEL Macro F1 Score: {macro_f1:.4f}")
    print("=====================================================")

if __name__ == '__main__':
    main()