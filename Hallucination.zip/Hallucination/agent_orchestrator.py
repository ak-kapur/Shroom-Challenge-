from sklearn.linear_model import LogisticRegression
import numpy as np
import joblib # New import

# This function is unchanged
def train_orchestrator_model(X_features, y_labels):
    print("Training Orchestrator Agent (Logistic Regression)...")
    model = LogisticRegression(random_state=42, class_weight='balanced')
    model.fit(X_features, y_labels)
    print("Orchestrator Agent trained.")
    return model

# This function is unchanged
def get_final_prediction(semantic_score, nli_score, pattern_score, model):
    features = np.array([semantic_score, nli_score, pattern_score]).reshape(1, -1)
    final_prob = model.predict_proba(features)[0][1]
    final_label = "Hallucination" if final_prob > 0.5 else "Not Hallucination"
    return final_prob, final_label

# --- NEW FUNCTIONS TO SAVE AND LOAD THE MODEL ---
def save_model(model, filepath):
    print(f"Saving orchestrator model to {filepath}...")
    joblib.dump(model, filepath)
    print("Model saved.")

def load_model(filepath):
    print(f"Loading orchestrator model from {filepath}...")
    model = joblib.load(filepath)
    print("Model loaded.")
    return model