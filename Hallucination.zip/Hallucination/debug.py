# # CORRECT
# from sentence_transformers import CrossEncoder

# def load_model():
#     """Loads the NLI Cross-Encoder model."""
#     print("Loading NLI model (cross-encoder/nli-deberta-v3-xsmall)...")
#     model = CrossEncoder('cross-encoder/nli-deberta-v3-xsmall')
#     print("NLI model loaded.")
#     return model

# # In agent_nli.py

# def get_nli_contradiction_score(data_point, model):
#     """Gets the NLI score for contradiction against the correct reference."""

#     # --- NEW LOGIC TO HANDLE THE 'ref' KEY ---
#     ref_type = data_point.get('ref')
#     reference_text = ""
#     if ref_type == 'tgt':
#         reference_text = data_point.get('tgt')
#     elif ref_type == 'src':
#         reference_text = data_point.get('src')
#     elif ref_type == 'either':
#         reference_text = data_point.get('tgt') or data_point.get('src')

#     hypothesis_text = data_point['hyp']

#     if not reference_text or not hypothesis_text:
#         return 0.0
        
#     scores = model.predict([(reference_text, hypothesis_text)])
#     # Output scores are in the order: [contradiction, entailment, neutral]
#     contradiction_score = scores[0][0]
#     return contradiction_score




from sentence_transformers import CrossEncoder

def load_model():
    print("Loading NLI model (cross-encoder/nli-deberta-v3-xsmall)...")
    model = CrossEncoder('cross-encoder/nli-deberta-v3-xsmall')
    print("NLI model loaded.")
    return model

def get_nli_contradiction_score(data_point, model):
    """Calculates NLI score with robust reference-finding logic."""
    hypothesis_text = data_point.get('hyp', '')
    target_text = data_point.get('tgt', '')
    source_text = data_point.get('src', '')

    # --- ROBUST LOGIC: Prefer target, but fall back to source ---
    if target_text and len(target_text.split()) > 2:
        reference_text = target_text
    else:
        reference_text = source_text

    if not reference_text or not hypothesis_text:
        return 0.0
        
    scores = model.predict([(reference_text, hypothesis_text)])
    return scores[0][0] # Return contradiction score