# from sentence_transformers import SentenceTransformer, util

# def load_model():
#     """Loads the Sentence Transformer model."""
#     print("Loading Semantic Analysis model (all-MiniLM-L6-v2)...")
#     model = SentenceTransformer('all-MiniLM-L6-v2')
#     print("Semantic Analysis model loaded.")
#     return model

# def get_semantic_similarity_score(data_point, model):
#     """Calculates the cosine similarity between the hypothesis and the correct reference."""
    
#     # --- NEW LOGIC TO HANDLE THE 'ref' KEY ---
#     ref_type = data_point.get('ref')
#     reference_text = ""
#     if ref_type == 'tgt':
#         reference_text = data_point.get('tgt')
#     elif ref_type == 'src':
#         reference_text = data_point.get('src')
#     elif ref_type == 'either':
#         # A good strategy for 'either' is to prefer the target, but fall back to the source
#         reference_text = data_point.get('tgt') or data_point.get('src')
    
#     hypothesis_text = data_point['hyp']

#     if not reference_text or not hypothesis_text:
#         return 0.0

#     embedding_ref = model.encode(reference_text, convert_to_tensor=True)
#     embedding_hyp = model.encode(hypothesis_text, convert_to_tensor=True)

#     cosine_similarity = util.pytorch_cos_sim(embedding_ref, embedding_hyp).item()
#     return cosine_similarity



from sentence_transformers import SentenceTransformer, util

def load_model():
    print("Loading Semantic Analysis model (all-MiniLM-L6-v2)...")
    model = SentenceTransformer('all-MiniLM-L6-v2')
    print("Semantic Analysis model loaded.")
    return model

def get_semantic_similarity_score(data_point, model):
    """Calculates cosine similarity with robust reference-finding logic."""
    hypothesis_text = data_point.get('hyp', '')
    target_text = data_point.get('tgt', '')
    source_text = data_point.get('src', '')
    
    # --- ROBUST LOGIC: Prefer target, but fall back to source ---
    # Also check if target looks like real text, not just a tag like "(historical)"
    if target_text and len(target_text.split()) > 2:
        reference_text = target_text
    else:
        reference_text = source_text

    if not reference_text or not hypothesis_text:
        return 0.0

    embedding_ref = model.encode(reference_text, convert_to_tensor=True)
    embedding_hyp = model.encode(hypothesis_text, convert_to_tensor=True)
    return util.pytorch_cos_sim(embedding_ref, embedding_hyp).item()