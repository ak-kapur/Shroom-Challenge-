# # CORRECT
# from sentence_transformers import CrossEncoder

# def load_model():
#     """Loads the NLI Cross-Encoder model."""
#     print("Loading NLI model (cross-encoder/nli-deberta-v3-xsmall)...")
#     model = CrossEncoder('cross-encoder/nli-deberta-v3-xsmall')
#     print("NLI model loaded.")
#     return model

# # In agent_nli.py

# def get_nli_contradiction_score(data_point, model):
#     """Gets the NLI score for contradiction against the correct reference."""

#     # --- NEW LOGIC TO HANDLE THE 'ref' KEY ---
#     ref_type = data_point.get('ref')
#     reference_text = ""
#     if ref_type == 'tgt':
#         reference_text = data_point.get('tgt')
#     elif ref_type == 'src':
#         reference_text = data_point.get('src')
#     elif ref_type == 'either':
#         reference_text = data_point.get('tgt') or data_point.get('src')

#     hypothesis_text = data_point['hyp']

#     if not reference_text or not hypothesis_text:
#         return 0.0
        
#     scores = model.predict([(reference_text, hypothesis_text)])
#     # Output scores are in the order: [contradiction, entailment, neutral]
#     contradiction_score = scores[0][0]
#     return contradiction_score




from sentence_transformers import CrossEncoder
import numpy as np # We need numpy for the softmax function

def load_model():
    """Loads the NLI Cross-Encoder model."""
    print("Loading NLI model (cross-encoder/nli-deberta-v3-xsmall)...")
    model = CrossEncoder('cross-encoder/nli-deberta-v3-xsmall')
    print("NLI model loaded.")
    return model

def get_nli_contradiction_score(data_point, model):
    """Calculates NLI score with robust reference-finding and softmax conversion."""
    hypothesis_text = data_point.get('hyp', '')
    target_text = data_point.get('tgt', '')
    source_text = data_point.get('src', '')

    # Robust logic to find the best reference text
    if target_text and len(target_text.split()) > 2:
        reference_text = target_text
    else:
        reference_text = source_text

    if not reference_text or not hypothesis_text:
        return 0.0
        
    # The model.predict() function returns LOGITS, not probabilities
    logits = model.predict([(reference_text, hypothesis_text)])
    
    # --- THE FIX: Apply the Softmax function to convert logits to probabilities ---
    # The formula is e^x / sum(e^x)
    probabilities = np.exp(logits) / np.sum(np.exp(logits))
    # -------------------------------------------------------------------------

    # The output order is [contradiction, entailment, neutral]
    # We want the probability of contradiction, which is the first element.
    contradiction_probability = probabilities[0][0]
    
    return contradiction_probability