import os, json
from tqdm import tqdm

CONFIDENCE_THRESHOLD = 0.95 # Start high and safe! Try 0.95, 0.90 later.

PSEUDO_DATA_DIR = 'pseudo_data'
SCORED_DATA_INPUT_FILE = os.path.join(PSEUDO_DATA_DIR, 'unlabeled_with_final_scores.json')
FINAL_DATASET_OUTPUT_FILE = os.path.join(PSEUDO_DATA_DIR, f'final_training_dataset_student_conf_{int(CONFIDENCE_THRESHOLD*100)}.json')

def main():
    print("--- Loading Datasets to Create Final Student Training Set ---")
    with open(r'D:\Hallucination\Data\SHROOM_dev-v2\SHROOM_dev-v2\val.model-agnostic.json',  encoding='utf-8') as f:
        agnostic_data = json.load(f)
    with open(r'D:\Hallucination\Data\SHROOM_dev-v2\SHROOM_dev-v2\val.model-aware.v2.json',  encoding='utf-8') as f:
        aware_data = json.load(f)
    human_labeled_data = agnostic_data + aware_data

    with open(SCORED_DATA_INPUT_FILE, 'r', encoding='utf-8') as f:
        scored_data = json.load(f)
    
    print(f"\n--- Filtering for confidence > {CONFIDENCE_THRESHOLD*100}% or < {(1-CONFIDENCE_THRESHOLD)*100}% ---")
    pseudo_labeled_data = []
    for dp in tqdm(scored_data, desc="Filtering Pre-Scored Data"):
        prob = dp.get('predicted_prob', 0.5)
        if prob > CONFIDENCE_THRESHOLD or prob < (1 - CONFIDENCE_THRESHOLD):
            new_dp = dp.copy()
            new_dp['label'] = "Hallucination" if prob > 0.5 else "Not Hallucination"
            pseudo_labeled_data.append(new_dp)
            
    print(f"Created a pseudo-labeled dataset with {len(pseudo_labeled_data)} examples.")
    final_dataset = human_labeled_data + pseudo_labeled_data
    
    print(f"\nSaving the final student dataset ({len(final_dataset)} items) to '{FINAL_DATASET_OUTPUT_FILE}'...")
    with open(FINAL_DATASET_OUTPUT_FILE, 'w', encoding='utf-8') as f:
        json.dump(final_dataset, f)
        
    print("Save complete.")

if __name__ == '__main__':
    main()