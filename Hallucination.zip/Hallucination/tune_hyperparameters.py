import os
import json
import numpy as np
from tqdm import tqdm
import lightgbm as lgb
import optuna # New import
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score

os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning)

# Import the new advanced feature extractor
from agent_pattern import extract_advanced_features
import agent_semantic, agent_nli

# Global cache for features to speed up tuning
FEATURE_CACHE = {}

def generate_hybrid_features(data_point, semantic_model, nli_model):
    """Generates the full feature vector for a data point, using a cache."""
    dp_id = data_point.get('id', hash(data_point['hyp'])) # Use ID if available
    if dp_id in FEATURE_CACHE:
        return FEATURE_CACHE[dp_id]
    
    semantic_score = agent_semantic.get_semantic_similarity_score(data_point, semantic_model)
    nli_score = agent_nli.get_nli_contradiction_score(data_point, nli_model)
    linguistic_features = extract_advanced_features(data_point)
    
    # No heuristic feature here, we let the model learn everything from raw signals
    feature_vector = [semantic_score, nli_score] + linguistic_features
    FEATURE_CACHE[dp_id] = feature_vector
    return feature_vector

def main():
    print("--- Loading Models and Data for Hyperparameter Tuning ---")
    semantic_model = agent_semantic.load_model()
    nli_model = agent_nli.load_model()

    agnostic_val_path = r'D:\Hallucination\Data\SHROOM_dev-v2\SHROOM_dev-v2\val.model-agnostic.json'
    aware_val_path = r'D:\Hallucination\Data\SHROOM_dev-v2\SHROOM_dev-v2\val.model-aware.v2.json'
    with open(agnostic_val_path, 'r', encoding='utf-8') as f: agnostic_data = json.load(f)
    with open(aware_val_path, 'r', encoding='utf-8') as f: aware_data = json.load(f)
    full_labeled_data = agnostic_data + aware_data

    print("\n--- Pre-calculating all features (this may take a moment) ---")
    X = np.array([generate_hybrid_features(dp, semantic_model, nli_model) for dp in tqdm(full_labeled_data, desc="Pre-calculating Features")])
    y = np.array([1 if dp['label'] == 'Hallucination' else 0 for dp in full_labeled_data])

    # Split data for the tuning process
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    def objective(trial):
        """Optuna objective function to maximize Macro F1 score."""
        params = {
            'objective': 'binary',
            'metric': 'binary_logloss',
            'n_estimators': trial.suggest_int('n_estimators', 200, 2000),
            'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3),
            'num_leaves': trial.suggest_int('num_leaves', 20, 300),
            'max_depth': trial.suggest_int('max_depth', 3, 12),
            'reg_alpha': trial.suggest_float('reg_alpha', 0.0, 1.0),
            'reg_lambda': trial.suggest_float('reg_lambda', 0.0, 1.0),
            'feature_fraction': trial.suggest_float('feature_fraction', 0.6, 1.0),
            'bagging_fraction': trial.suggest_float('bagging_fraction', 0.6, 1.0),
            'bagging_freq': trial.suggest_int('bagging_freq', 1, 7),
            'verbose': -1,
            'n_jobs': -1,
            'seed': 42
        }
        
        model = lgb.LGBMClassifier(**params)
        model.fit(X_train, y_train)
        
        preds = model.predict(X_val)
        score = f1_score(y_val, preds, average='macro')
        return score

    print("\n--- Starting Hyperparameter Tuning with Optuna ---")
    study = optuna.create_study(direction='maximize')
    study.optimize(objective, n_trials=100) # Run 100 trials to find the best settings

    print("\n--- Tuning Complete ---")
    print(f"Best trial Macro F1 score: {study.best_value:.4f}")
    print("Best parameters found:")
    print(study.best_params)
    
    print("\nAction: Copy these 'Best parameters' into your final training script.")

if __name__ == '__main__':
    main()