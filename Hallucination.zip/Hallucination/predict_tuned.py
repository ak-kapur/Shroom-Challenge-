import os
import json
import numpy as np
from tqdm import tqdm
import joblib
from sklearn.metrics import classification_report, f1_score

os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning)

# Import the feature generators
from agent_pattern import extract_advanced_features
import agent_semantic
import agent_nli

# --- Define Paths ---
MODEL_DIR = 'tuned_model'
TUNED_MODEL_PATH = os.path.join(MODEL_DIR, 'tuned_lgbm_model.joblib')
TEST_DATA_PATH = 'D:\\Hallucination\\Data\\SHROOM_test-labeled\\SHROOM_test-labeled\\test.model-agnostic.json'

def generate_hybrid_features(data_point, semantic_model, nli_model):
    """Re-create the exact same feature generation function used for training."""
    semantic_score = agent_semantic.get_semantic_similarity_score(data_point, semantic_model)
    nli_score = agent_nli.get_nli_contradiction_score(data_point, nli_model)
    linguistic_features = extract_advanced_features(data_point)
    return [semantic_score, nli_score] + linguistic_features

def main():
    print("--- Loading Final Tuned Model and Feature Generators ---")
    if not os.path.exists(TUNED_MODEL_PATH):
        print("Error: Tuned model not found. Please run main_tuned.py first.")
        return
            
    semantic_model = agent_semantic.load_model()
    nli_model = agent_nli.load_model()
    tuned_model = joblib.load(TUNED_MODEL_PATH)
    
    with open(TEST_DATA_PATH, 'r', encoding='utf-8') as f:
        test_data = json.load(f)
    
    print("\n--- Generating Predictions with Final Tuned Model ---")
    predicted_labels = []
    for dp in tqdm(test_data, desc="Predicting with Tuned Model"):
        feature_vector = generate_hybrid_features(dp, semantic_model, nli_model)
        prediction = tuned_model.predict(np.array(feature_vector).reshape(1, -1))[0]
        final_label = "Hallucination" if prediction == 1 else "Not Hallucination"
        predicted_labels.append(final_label)
    
    print("\n--- TUNED MODEL Performance on Official Test Data ---")
    true_labels = [dp['label'] for dp in test_data]
    print(classification_report(true_labels, predicted_labels))
    macro_f1 = f1_score(true_labels, predicted_labels, average='macro', zero_division=0)
    
    print("=====================================================")
    print(f"  FINAL TUNED MODEL Macro F1 Score: {macro_f1:.4f}")
    print("=====================================================")

if __name__ == '__main__':
    main()