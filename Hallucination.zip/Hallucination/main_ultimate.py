import os
import json
import numpy as np
from tqdm import tqdm
import lightgbm as lgb
import joblib

os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning)

from agent_pattern import extract_advanced_features
import agent_semantic, agent_nli

# --- Configuration ---
CONFIDENCE_THRESHOLD = 0.95 
# ---------------------

MODEL_DIR = f'ultimate_model_conf_{int(CONFIDENCE_THRESHOLD*100)}'
ULTIMATE_MODEL_PATH = os.path.join(MODEL_DIR, 'ultimate_lgbm_model.joblib')
FINAL_TRAINING_DATA_PATH = os.path.join('pseudo_data', f'final_training_dataset_student_conf_{int(CONFIDENCE_THRESHOLD*100)}.json')

def get_heuristic_prediction(data_point, semantic_score, nli_score):
    linguistic_features = extract_advanced_features(data_point)
    is_circular_def, number_mismatch = linguistic_features[4], linguistic_features[5]
    if nli_score > 0.95: return "Hallucination"
    if semantic_score < 0.5: return "Hallucination"
    if is_circular_def == 1 or number_mismatch == 1: return "Hallucination"
    if semantic_score > 0.90 and nli_score < 0.1: return "Not Hallucination"
    if semantic_score > 0.75 and nli_score < 0.5: return "Not Hallucination"
    return "Not Hallucination"

def generate_hybrid_features(data_point, semantic_model, nli_model):
    semantic_score = agent_semantic.get_semantic_similarity_score(data_point, semantic_model)
    nli_score = agent_nli.get_nli_contradiction_score(data_point, nli_model)
    linguistic_features = extract_advanced_features(data_point)
    heuristic_pred_str = get_heuristic_prediction(data_point, semantic_score, nli_score)
    heuristic_feature = 1 if heuristic_pred_str == 'Hallucination' else 0
    return [semantic_score, nli_score] + linguistic_features + [heuristic_feature]

def main():
    if not os.path.exists(MODEL_DIR): os.makedirs(MODEL_DIR)

    print("--- Loading Models and Data for ULTIMATE Training ---")
    semantic_model = agent_semantic.load_model()
    nli_model = agent_nli.load_model()
    
    with open(FINAL_TRAINING_DATA_PATH, 'r', encoding='utf-8') as f:
        train_data = json.load(f)
    print(f"Loaded {len(train_data)} final training data points.")

    print("\n--- Generating Final Hybrid Feature Set for ULTIMATE Model ---")
    X_train = np.array([generate_hybrid_features(dp, semantic_model, nli_model) for dp in tqdm(train_data, desc="Generating Ultimate Features")])
    y_train = np.array([1 if dp['label'] == 'Hallucination' else 0 for dp in train_data])

    print("\n--- Training the ULTIMATE LightGBM Model with Best Hyperparameters ---")
    
    # --- PASTE THE BEST PARAMETERS FROM OPTUNA HERE ---
    best_params = {
        'objective': 'binary',
        'metric': 'binary_logloss',
        'n_estimators': 500,
        'learning_rate': 0.053162862150692373,
        'num_leaves': 92,
        'max_depth': 9,
        'reg_alpha': 0.03137265900475432,
        'reg_lambda': 0.005486305373846529,
        'feature_fraction': 0.5630607910058488,
        'bagging_fraction': 0.8652240405895418,
        'bagging_freq': 6,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42
    }
    # ----------------------------------------------------
    
    ultimate_model = lgb.LGBMClassifier(**best_params)
    ultimate_model.fit(X_train, y_train)
    
    print("Ultimate model trained successfully.")
    joblib.dump(ultimate_model, ULTIMATE_MODEL_PATH)
    print(f"Model saved to {ULTIMATE_MODEL_PATH}")
    print("\nNext step: Run predict_ultimate.py to evaluate this model on the test set.")

if __name__ == '__main__':
    main()