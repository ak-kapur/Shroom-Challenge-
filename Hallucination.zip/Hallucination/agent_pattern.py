# import lightgbm as lgb
# import numpy as np
# import nltk
# import joblib
# import re # Import regular expressions for number finding

# def extract_advanced_features(data_point): # <-- This function must exist!
#     """
#     Extracts a more powerful and diverse set of linguistic and contextual features.
#     """
#     hypothesis = data_point.get('hyp', '')
#     source = data_point.get('src', '')
#     target = data_point.get('tgt', '')
#     task = data_point.get('task', '')

#     # --- Basic Features ---
#     len_hyp = len(hypothesis)
#     tokens = nltk.word_tokenize(hypothesis.lower())
#     num_tokens = len(tokens) if tokens else 0
#     lexical_diversity = len(set(tokens)) / num_tokens if num_tokens > 0 else 0

#     # --- Contextual & Relational Features ---
#     ref_text = target if task != 'PG' else source
#     len_ref = len(ref_text) if ref_text else 1
#     length_ratio = len_hyp / len_ref

#     ref_tokens = set(nltk.word_tokenize(ref_text.lower()))
#     hyp_tokens = set(tokens)
#     if not ref_tokens and not hyp_tokens: jaccard_sim = 0
#     else:
#         intersection = len(ref_tokens.intersection(hyp_tokens))
#         union = len(ref_tokens.union(hyp_tokens))
#         jaccard_sim = intersection / union if union != 0 else 0

#     # --- Task-Specific Hallucination Features ---
#     is_circular_def = 0
#     if task == 'DM' and source:
#         try:
#             if '<define>' in source:
#                 define_start = source.find('<define>') + len('<define>')
#                 define_end = source.find('</define>')
#                 word_to_define = source[define_start:define_end].strip().lower()
#             else:
#                 word_to_define = source.split('What is the meaning of ')[-1].replace('?', '').strip().lower()
#             if word_to_define in hyp_tokens:
#                 is_circular_def = 1
#         except: pass

#     def get_numbers(text):
#         return set(re.findall(r'\d+\.?\d*', text))
    
#     ref_numbers = get_numbers(ref_text)
#     hyp_numbers = get_numbers(hypothesis)
#     number_mismatch = 1 if not hyp_numbers.issubset(ref_numbers) else 0

#     question_in_hyp = 1 if '?' in hypothesis else 0
#     repetition_score = 1 - lexical_diversity if num_tokens > 0 else 0

#     return [
#         len_hyp, lexical_diversity, jaccard_sim, length_ratio,
#         is_circular_def, number_mismatch, question_in_hyp, repetition_score
#     ]

# # The rest of the functions are here for completeness but are not used by the unified model script
# def train_pattern_model(X_features, y_labels): pass
# def get_pattern_risk_score(data_point, model): pass
# def save_model(model, filepath): pass
# def load_model(filepath): pass



import lightgbm as lgb
import numpy as np
import nltk
import joblib
import re
import spacy # New import for NER
from nltk.corpus import stopwords # New import for stopwords

# --- Load NLP models and resources once to save time ---
try:
    STOP_WORDS = set(stopwords.words('english'))
except LookupError:
    nltk.download('stopwords')
    STOP_WORDS = set(stopwords.words('english'))

print("Loading spaCy model for NER...")
NLP = spacy.load("en_core_web_sm")
print("spaCy model loaded.")
# --------------------------------------------------------

def extract_advanced_features(data_point):
    """
    Extracts a highly advanced set of linguistic, contextual, and entity-based features.
    """
    hypothesis = data_point.get('hyp', '')
    source = data_point.get('src', '')
    target = data_point.get('tgt', '')
    task = data_point.get('task', '')

    # Basic text properties
    len_hyp = len(hypothesis)
    tokens = [token.text for token in NLP(hypothesis.lower())] # Use spaCy's tokenizer
    num_tokens = len(tokens) if tokens else 0
    
    # --- Existing Features (Recalculated for consistency) ---
    lexical_diversity = len(set(tokens)) / num_tokens if num_tokens > 0 else 0
    ref_text = target if task != 'PG' else source
    len_ref = len(ref_text) if ref_text else 1
    length_ratio = len_hyp / len_ref

    ref_tokens_set = set(nltk.word_tokenize(ref_text.lower()))
    hyp_tokens_set = set(tokens)
    intersection = len(ref_tokens_set.intersection(hyp_tokens_set))
    union = len(ref_tokens_set.union(hyp_tokens_set))
    jaccard_sim = intersection / union if union != 0 else 0

    def get_numbers(text): return set(re.findall(r'\d+\.?\d*', text))
    number_mismatch = 1 if not get_numbers(hypothesis).issubset(get_numbers(ref_text)) else 0

    # --- NEW ADVANCED FEATURES ---

    # Feature 8: Stopword Ratio
    # High ratio of filler words might indicate vague, generated text.
    if num_tokens > 0:
        stopword_count = len([word for word in tokens if word in STOP_WORDS])
        stopword_ratio = stopword_count / num_tokens
    else:
        stopword_ratio = 0
        
    # Feature 9: Average Word Length
    # Can indicate a change in complexity or style.
    if num_tokens > 0:
        avg_word_length = sum(len(word) for word in tokens) / num_tokens
    else:
        avg_word_length = 0

    # Feature 10 & 11: Named Entity Recognition (NER) Features
    # The most powerful new features. Do new entities appear out of nowhere?
    doc_ref = NLP(ref_text)
    doc_hyp = NLP(hypothesis)
    
    entities_ref = {ent.text.lower() for ent in doc_ref.ents}
    entities_hyp = {ent.text.lower() for ent in doc_hyp.ents}

    # How many new entities were invented in the hypothesis?
    new_entity_count = len(entities_hyp - entities_ref)
    
    # What percentage of hypothesis entities are grounded in the reference?
    if len(entities_hyp) > 0:
        entity_overlap_ratio = len(entities_hyp.intersection(entities_ref)) / len(entities_hyp)
    else:
        entity_overlap_ratio = 1.0 # If no entities, there's no mismatch

    return [
        len_hyp, lexical_diversity, jaccard_sim, length_ratio,
        number_mismatch, stopword_ratio, avg_word_length,
        new_entity_count, entity_overlap_ratio
    ]

# The functions below are for the non-unified models and can be left as is.
def train_pattern_model(X_features, y_labels): pass
def get_pattern_risk_score(data_point, model): pass
def save_model(model, filepath): pass
def load_model(filepath): pass