# File: main_filter.py
import os, json
from tqdm import tqdm
import numpy as np
import lightgbm as lgb
import joblib
from agent_pattern import extract_advanced_features

os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning)

import agent_semantic, agent_nli

MODEL_DIR = 'filter_model'
FILTER_MODEL_PATH = os.path.join(MODEL_DIR, 'filter_lgbm_model.joblib')

def main():
    if not os.path.exists(MODEL_DIR): os.makedirs(MODEL_DIR)

    semantic_model = agent_semantic.load_model()
    # NLI model is NOT needed for training this model

    # Load and combine validation sets
    agnostic_val_path = r'D:\Hallucination\Data\SHROOM_dev-v2\SHROOM_dev-v2\val.model-agnostic.json'
    aware_val_path = r'D:\Hallucination\Data\SHROOM_dev-v2\SHROOM_dev-v2\val.model-aware.v2.json'
    with open(agnostic_val_path, 'r', encoding='utf-8') as f: agnostic_data = json.load(f)
    with open(aware_val_path, 'r', encoding='utf-8') as f: aware_data = json.load(f)
    train_data = agnostic_data + aware_data
    
    print("\n--- Generating Feature Set for the Filter Model (NO NLI SCORE) ---")
    X_train = []
    y_train = [1 if dp['label'] == 'Hallucination' else 0 for dp in train_data]

    for dp in tqdm(train_data, desc="Generating Filter Features"):
        semantic_score = agent_semantic.get_semantic_similarity_score(dp, semantic_model)
        linguistic_features = extract_advanced_features(dp)
        feature_vector = [semantic_score] + linguistic_features # Note: NLI score is excluded
        X_train.append(feature_vector)

    print("\n--- Training the Two-Stage Filter Model ---")
    lgbm_params = {'objective': 'binary', 'metric': 'binary_logloss', 'n_estimators': 200, 'seed': 42}
    filter_model = lgb.LGBMClassifier(**lgbm_params)
    filter_model.fit(np.array(X_train), np.array(y_train))
    
    print("Filter model trained successfully.")
    joblib.dump(filter_model, FILTER_MODEL_PATH)
    print(f"Model saved to {FILTER_MODEL_PATH}")

if __name__ == '__main__':
    main()