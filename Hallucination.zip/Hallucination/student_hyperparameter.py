import os
import json
import numpy as np
from tqdm import tqdm
import lightgbm as lgb
import optuna
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score

os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning)

# Import your feature generation logic
from agent_pattern import extract_advanced_features
import agent_semantic, agent_nli

# --- Configuration ---
# This MUST match the dataset you want to use for training
CONFIDENCE_THRESHOLD = 0.95 
# ---------------------

# --- Define Paths ---
FINAL_TRAINING_DATA_PATH = os.path.join('pseudo_data', f'final_training_dataset_student_conf_{int(CONFIDENCE_THRESHOLD*100)}.json')
FEATURE_CACHE = {}

def get_heuristic_prediction(data_point, semantic_score, nli_score):
    linguistic_features = extract_advanced_features(data_point)
    is_circular_def, number_mismatch = linguistic_features[4], linguistic_features[5]
    if nli_score > 0.95: return "Hallucination"
    if semantic_score < 0.5: return "Hallucination"
    if is_circular_def == 1 or number_mismatch == 1: return "Hallucination"
    if semantic_score > 0.90 and nli_score < 0.1: return "Not Hallucination"
    if semantic_score > 0.75 and nli_score < 0.5: return "Not Hallucination"
    return "Not Hallucination"

def generate_hybrid_features(data_point, semantic_model, nli_model):
    """Generates the full feature vector for a data point, using a cache for speed."""
    # Use a unique ID from the data if available, otherwise use a hash of the hypothesis
    dp_id = data_point.get('id', hash(data_point['hyp']))
    # Add task to the key to ensure uniqueness if IDs overlap between sources
    cache_key = f"{data_point.get('task', 'task')}-{dp_id}"
    if cache_key in FEATURE_CACHE:
        return FEATURE_CACHE[cache_key]

    semantic_score = agent_semantic.get_semantic_similarity_score(data_point, semantic_model)
    nli_score = agent_nli.get_nli_contradiction_score(data_point, nli_model)
    linguistic_features = extract_advanced_features(data_point)
    heuristic_pred_str = get_heuristic_prediction(data_point, semantic_score, nli_score)
    heuristic_feature = 1 if heuristic_pred_str == 'Hallucination' else 0
    
    feature_vector = [semantic_score, nli_score] + linguistic_features + [heuristic_feature]
    FEATURE_CACHE[cache_key] = feature_vector
    return feature_vector

def main():
    print("--- Loading Models and Data for STUDENT Hyperparameter Tuning ---")
    semantic_model = agent_semantic.load_model()
    nli_model = agent_nli.load_model()

    try:
        with open(FINAL_TRAINING_DATA_PATH, 'r', encoding='utf-8') as f:
            full_student_data = json.load(f)
        print(f"Loaded {len(full_student_data)} data points from '{os.path.basename(FINAL_TRAINING_DATA_PATH)}'.")
    except FileNotFoundError:
        print(f"Error: Dataset not found. Please run create_final_dataset_v2.py with CONFIDENCE_THRESHOLD = {CONFIDENCE_THRESHOLD} first.")
        return

    print("\n--- Pre-calculating all features for tuning (this may take a moment) ---")
    X = np.array([generate_hybrid_features(dp, semantic_model, nli_model) for dp in tqdm(full_student_data, desc="Pre-calculating Features")])
    y = np.array([1 if dp['label'] == 'Hallucination' else 0 for dp in full_student_data])

    # Split data for the tuning process (e.g., 80% for training, 20% for validation within the tuning)
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    def objective(trial):
        """Optuna objective function to maximize Macro F1 score."""
        params = {
            'objective': 'binary', 'metric': 'binary_logloss', 'verbosity': -1, 'n_jobs': -1, 'seed': 42,
            'n_estimators': trial.suggest_int('n_estimators', 500, 2500, step=100),
            'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.2, log=True),
            'num_leaves': trial.suggest_int('num_leaves', 20, 500),
            'max_depth': trial.suggest_int('max_depth', 5, 15),
            'reg_alpha': trial.suggest_float('reg_alpha', 1e-3, 10.0, log=True),
            'reg_lambda': trial.suggest_float('reg_lambda', 1e-3, 10.0, log=True),
            'feature_fraction': trial.suggest_float('feature_fraction', 0.5, 1.0),
            'bagging_fraction': trial.suggest_float('bagging_fraction', 0.5, 1.0),
            'bagging_freq': trial.suggest_int('bagging_freq', 1, 7),
        }
        
        model = lgb.LGBMClassifier(**params)
        model.fit(X_train, y_train)
        preds = model.predict(X_val)
        score = f1_score(y_val, preds, average='macro')
        return score

    print("\n--- Starting Student Model Hyperparameter Tuning with Optuna ---")
    study = optuna.create_study(direction='maximize')
    study.optimize(objective, n_trials=50) # Run 50 trials (can be increased for more thorough search)

    print("\n--- Tuning Complete ---")
    print(f"Best trial Macro F1 score on student data validation split: {study.best_value:.4f}")
    print("Best parameters found for the STUDENT model:")
    print(study.best_params)
    
    print("\nAction: Copy these NEW 'Best parameters' into a final student training and prediction script.")

if __name__ == '__main__':
    main()