import json

def create_data_sample(filepath='D:\\Hallucination\\Data\\SHROOM_test-labeled\\SHROOM_test-labeled\\test.model-aware.json'):
    """
    Reads a large JSON file and extracts the first example for each unique task type.
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error: The file '{filepath}' was not found in this directory.")
        return

    samples = {}
    task_types_found = set()
    
    for datapoint in data:
        task = datapoint.get('task')
        if task not in task_types_found:
            samples[task] = datapoint
            task_types_found.add(task)
        
        # Stop once we've found one of each of the main task types
        if 'DM' in task_types_found and 'MT' in task_types_found and 'PG' in task_types_found:
            break
            
    print(f"--- Found {len(samples)} unique task types in the first part of the file ---\n")
    
    # Print the collected samples in a clean, readable format
    for task_name, sample in samples.items():
        print(f"--- Example for Task: {task_name} ---")
        # Use json.dumps for pretty printing
        print(json.dumps(sample, indent=4))
        print("\n")


if __name__ == '__main__':
    create_data_sample()