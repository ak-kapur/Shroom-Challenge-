import os
import json
import numpy as np
from tqdm import tqdm
import lightgbm as lgb
import joblib
from sklearn.metrics import classification_report, f1_score

# Add this fix for the OMP error and warning filters
os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning)

# Import our feature-generating agents and functions
import agent_semantic
import agent_nli
from agent_pattern import extract_advanced_features

# --- Define Paths ---
MODEL_DIR = 'hybrid_model' # A new folder for our best model
HYBRID_MODEL_PATH = os.path.join(MODEL_DIR, 'hybrid_lgbm_model.joblib')
TEST_DATA_PATH = 'D:\\Hallucination\\Data\\SHROOM_test-labeled\\SHROOM_test-labeled\\test.model-agnostic.json'


# --- The Heuristic Rule Engine (from our successful heuristic model) ---
def get_heuristic_prediction(data_point, semantic_score, nli_score):
    """Makes a prediction based on a set of hard-coded, logical rules."""
    linguistic_features = extract_advanced_features(data_point)
    is_circular_def = linguistic_features[4]
    number_mismatch = linguistic_features[5]

    if nli_score > 0.95: return "Hallucination"
    if semantic_score < 0.5: return "Hallucination"
    if is_circular_def == 1 or number_mismatch == 1: return "Hallucination"
    if semantic_score > 0.90 and nli_score < 0.1: return "Not Hallucination"
    if semantic_score > 0.75 and nli_score < 0.5: return "Not Hallucination"
    return "Not Hallucination"


def generate_hybrid_features(data_point, semantic_model, nli_model):
    """
    Generates a single, powerful feature vector combining all agent outputs.
    """
    # 1. Get scores from transformer models
    semantic_score = agent_semantic.get_semantic_similarity_score(data_point, semantic_model)
    nli_score = agent_nli.get_nli_contradiction_score(data_point, nli_model)
    
    # 2. Get advanced linguistic features
    linguistic_features = extract_advanced_features(data_point)
    
    # 3. Get the prediction from our successful heuristic model
    heuristic_pred_str = get_heuristic_prediction(data_point, semantic_score, nli_score)
    heuristic_feature = 1 if heuristic_pred_str == 'Hallucination' else 0 # Convert to a number
    
    # 4. Combine them all into one flat list
    # [sem_score, nli_score, ling_feat_1, ling_feat_2, ..., heuristic_feature]
    unified_feature_vector = [semantic_score, nli_score] + linguistic_features + [heuristic_feature]
    
    return unified_feature_vector


def main():
    if not os.path.exists(MODEL_DIR): os.makedirs(MODEL_DIR)

    # --- Part 1: Load Feature-Generating Models ---
    print("--- Initializing Pre-trained Models ---")
    semantic_model = agent_semantic.load_model()
    nli_model = agent_nli.load_model()

    # --- Part 2: Load and Combine Labeled Datasets for Training ---
    print("\n--- Loading and Combining Labeled Datasets for Hybrid Training ---")
    agnostic_val_path = r'D:\Hallucination\Data\SHROOM_dev-v2\SHROOM_dev-v2\val.model-agnostic.json'
    aware_val_path = r'D:\Hallucination\Data\SHROOM_dev-v2\SHROOM_dev-v2\val.model-aware.v2.json'
    with open(agnostic_val_path, 'r', encoding='utf-8') as f: agnostic_data = json.load(f)
    with open(aware_val_path, 'r', encoding='utf-8') as f: aware_data = json.load(f)
    train_data = agnostic_data + aware_data
    print(f"Total labeled data points for training: {len(train_data)}")

    # --- Part 3: Generate the Hybrid Feature Set for the entire training data ---
    print("\n--- Generating Hybrid Feature Set for Training ---")
    X_train = []
    y_train = [1 if dp['label'] == 'Hallucination' else 0 for dp in train_data]

    for dp in tqdm(train_data, desc="Generating Hybrid Features"):
        feature_vector = generate_hybrid_features(dp, semantic_model, nli_model)
        X_train.append(feature_vector)

    # --- Part 4: Train the Single, Hybrid Model ---
    print("\n--- Training the Hybrid LightGBM Model ---")
    lgbm_params = {
        'objective': 'binary', 'metric': 'binary_logloss', 'n_estimators': 200,
        'learning_rate': 0.05, 'num_leaves': 31,
        'reg_alpha': 0.1, 'reg_lambda': 0.1, 'verbose': -1, 'seed': 42
    }
    
    hybrid_model = lgb.LGBMClassifier(**lgbm_params)
    hybrid_model.fit(np.array(X_train), np.array(y_train))
    
    print("Hybrid model trained successfully.")
    joblib.dump(hybrid_model, HYBRID_MODEL_PATH)
    print(f"Model saved to {HYBRID_MODEL_PATH}")


    # --- Part 5: Evaluate the Hybrid Model on the Official Test Data ---
    print(f"\n--- Evaluating Hybrid Model on Test Data ---")
    with open(TEST_DATA_PATH, 'r', encoding='utf-8') as f: test_data = json.load(f)
    true_labels = [dp['label'] for dp in test_data]
    predicted_labels = []

    for dp in tqdm(test_data, desc="Predicting with Hybrid Model"):
        hybrid_feature_vector = generate_hybrid_features(dp, semantic_model, nli_model)
        prediction = hybrid_model.predict(np.array(hybrid_feature_vector).reshape(1, -1))[0]
        final_label = "Hallucination" if prediction == 1 else "Not Hallucination"
        predicted_labels.append(final_label)

    print("\n--- HYBRID MODEL Performance on Official Test Data ---")
    print(classification_report(true_labels, predicted_labels))
    macro_f1 = f1_score(true_labels, predicted_labels, average='macro', zero_division=0)
    
    print("=====================================================")
    print(f"  HYBRID MODEL Macro F1 Score: {macro_f1:.4f}")
    print("=====================================================")

if __name__ == '__main__':
    main()