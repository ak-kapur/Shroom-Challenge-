import os
import json
from tqdm import tqdm
from sklearn.metrics import classification_report, f1_score

os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'

# Import our feature-generating agents
import agent_semantic
import agent_nli
from agent_pattern import extract_advanced_features # We'll still use our advanced features

# --- The Heuristic Rule Engine ---
def get_heuristic_prediction(data_point, semantic_score, nli_score):
    """
    Makes a prediction based on a set of hard-coded, logical rules.
    NO TRAINED MODEL IS USED HERE.
    """
    # Get the advanced linguistic features for our rules
    linguistic_features = extract_advanced_features(data_point)
    # Unpack for readability
    is_circular_def = linguistic_features[4]
    number_mismatch = linguistic_features[5]

    # Rule 1: High-confidence NLI contradiction is a definite hallucination.
    if nli_score > 0.95:
        return "Hallucination"

    # Rule 2: Extremely low semantic similarity is a definite hallucination.
    if semantic_score < 0.5:
        return "Hallucination"

    # Rule 3: Task-specific red flags are definite hallucinations.
    if is_circular_def == 1 or number_mismatch == 1:
        return "Hallucination"

    # Rule 4: Very high similarity AND low contradiction is a definite NON-hallucination.
    # This is the most important rule to fix our recall problem.
    if semantic_score > 0.90 and nli_score < 0.1:
        return "Not Hallucination"
        
    # Rule 5: Medium similarity is likely okay if there's no contradiction.
    if semantic_score > 0.75 and nli_score < 0.5:
        return "Not Hallucination"

    # Default Case: If we are not sure, let's be conservative and assume it's okay.
    # This is the opposite of what our trained model was doing.
    return "Not Hallucination"


def main():
    print("--- Loading Pre-trained Models for Heuristic Inference ---")
    semantic_model = agent_semantic.load_model()
    nli_model = agent_nli.load_model()
    
    # Load the official test data
    TEST_DATA_PATH = 'D:\\Hallucination\\Data\\SHROOM_test-labeled\\SHROOM_test-labeled\\test.model-agnostic.json'
    with open(TEST_DATA_PATH, 'r', encoding='utf-8') as f:
        test_data = json.load(f)
    print(f"Loaded {len(test_data)} test data points.")

    print("\n--- Generating Predictions using HEURISTIC model ---")
    predicted_labels = []
    for dp in tqdm(test_data, desc="Predicting with Heuristics"):
        semantic_score = agent_semantic.get_semantic_similarity_score(dp, semantic_model)
        nli_score = agent_nli.get_nli_contradiction_score(dp, nli_model)
        
        final_label = get_heuristic_prediction(dp, semantic_score, nli_score)
        predicted_labels.append(final_label)
    
    print("\n--- HEURISTIC MODEL Performance on Official Test Data ---")
    true_labels = [dp['label'] for dp in test_data]
    print(classification_report(true_labels, predicted_labels))
    macro_f1 = f1_score(true_labels, predicted_labels, average='macro', zero_division=0)
    
    print("=====================================================")
    print(f"  HEURISTIC MODEL Macro F1 Score: {macro_f1:.4f}")
    print("=====================================================")

if __name__ == '__main__':
    main()