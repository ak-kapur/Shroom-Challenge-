import os
import json
import numpy as np
from tqdm import tqdm
import lightgbm as lgb
import joblib

os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning)

# Import the advanced feature extractor and base model loaders
from agent_pattern import extract_advanced_features
import agent_semantic, agent_nli

# --- Define Paths ---
MODEL_DIR = 'tuned_model' # New folder for our BEST and FINAL model
TUNED_MODEL_PATH = os.path.join(MODEL_DIR, 'tuned_lgbm_model.joblib')

def generate_hybrid_features(data_point, semantic_model, nli_model):
    """Generates the full feature vector (semantic + nli + advanced linguistic)."""
    semantic_score = agent_semantic.get_semantic_similarity_score(data_point, semantic_model)
    nli_score = agent_nli.get_nli_contradiction_score(data_point, nli_model)
    linguistic_features = extract_advanced_features(data_point)
    return [semantic_score, nli_score] + linguistic_features

def main():
    if not os.path.exists(MODEL_DIR): os.makedirs(MODEL_DIR)

    # --- Part 1: Load Feature-Generating Models & All Labeled Data ---
    print("--- Loading Models and Data for Final Training ---")
    semantic_model = agent_semantic.load_model()
    nli_model = agent_nli.load_model()

    agnostic_val_path = r'D:\Hallucination\Data\SHROOM_dev-v2\SHROOM_dev-v2\val.model-agnostic.json'
    aware_val_path = r'D:\Hallucination\Data\SHROOM_dev-v2\SHROOM_dev-v2\val.model-aware.v2.json'
    with open(agnostic_val_path, 'r', encoding='utf-8') as f: agnostic_data = json.load(f)
    with open(aware_val_path, 'r', encoding='utf-8') as f: aware_data = json.load(f)
    train_data = agnostic_data + aware_data
    print(f"Loaded {len(train_data)} total labeled data points for training.")

    # --- Part 2: Generate the Full Feature Set ---
    print("\n--- Generating Final Feature Set ---")
    X_train = np.array([generate_hybrid_features(dp, semantic_model, nli_model) for dp in tqdm(train_data, desc="Generating Features")])
    y_train = np.array([1 if dp['label'] == 'Hallucination' else 0 for dp in train_data])

    # --- Part 3: Train the Final, Tuned Model ---
    print("\n--- Training the Final, Tuned LightGBM Model ---")
    
    # --- PASTE THE BEST PARAMETERS FROM OPTUNA HERE ---
    best_params = {
        'objective': 'binary',
        'metric': 'binary_logloss',
        'n_estimators': 704,
        'learning_rate': 0.010814117771889063,
        'num_leaves': 85,
        'max_depth': 6,
        'reg_alpha': 0.9059847087336768,
        'reg_lambda': 0.7004043033151797,
        'feature_fraction': 0.9456202723432793,
        'bagging_fraction': 0.9654905315853703,
        'bagging_freq': 1,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42
    }
    # ----------------------------------------------------
    
    final_model = lgb.LGBMClassifier(**best_params)
    final_model.fit(X_train, y_train)
    
    print("Final tuned model trained successfully.")
    joblib.dump(final_model, TUNED_MODEL_PATH)
    print(f"Model saved to {TUNED_MODEL_PATH}")

if __name__ == '__main__':
    main()